@extends('layouts.app')
@section('title') ড্যাশবোর্ড | Components @endsection

@section('third_party_stylesheets')

@endsection

@section('content')
	@section('page-header') Components @endsection
    <div class="container-fluid">
        <h1 class="text-black-50">You are logged in!</h1>
    </div>
@endsection

@section('third_party_scripts')

@endsection